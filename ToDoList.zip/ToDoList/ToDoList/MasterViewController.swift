//
//  MasterViewController.swift
//  ToDoList
//
//  Created by Steven Dutton on 21/4/18.
//  Copyright © 2018 Steven Dutton. All rights reserved.
//

import UIKit

class MasterViewController: UITableViewController {

    let model = ["Bread", "Milk", "Butter"]
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return model.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
        let i = indexPath.row
        let text = model[i]
        cell.textLabel?.text = text
        return cell
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        navigationItem.leftBarButtonItem = editButtonItem
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

