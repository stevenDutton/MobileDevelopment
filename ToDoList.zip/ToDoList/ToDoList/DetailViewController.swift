//
//  ViewController.swift
//  ToDoList
//
//  Created by Steven Dutton on 25/4/18.
//  Copyright © 2018 Steven Dutton. All rights reserved.
//

import UIKit

protocol DetailViewControllerDelegate: class {
    func detailViewControllerDidUpdate(_ detailViewController: DetailViewController)
}

class DetailViewController: UIViewController, UITextFieldDelegate {
    
    @IBOutlet weak var detailTextField: UITextField!
    weak var delegate: DetailViewControllerDelegate?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        configureView()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    public func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        detailItem = textField.text
        delegate?.detailViewControllerDidUpdate(self)
        return true
    }
    
    func configureView() {
        // Update the user interface for the detail item.
        if let detail = detailItem {
            if let textField = detailTextField {
                textField.text = detail.description
            }
        }
    }
    
    var detailItem: String? {
        didSet {
            // Update the view.
            configureView()
        }
    }
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
