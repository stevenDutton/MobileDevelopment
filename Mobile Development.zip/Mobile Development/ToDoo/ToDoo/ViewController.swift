//
//  ViewController.swift
//  ToDoo
//
//  Created by Steven Dutton on 7/3/18.
//  Copyright © 2018 Steven Dutton. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {
    
    @IBOutlet weak var itemTextView: UITextView!
    @IBOutlet weak var itemLabel: UILabel!
    
    @IBAction func itemButton(_ sender: UIButton) {
        let newText = String(format: "You have %@ items in your list", String(countLinesTextView(str: itemTextView.text)))
        itemLabel.text = newText
    }
    
    func countLinesTextView(str: String) -> Int{
        let numLines =  str.components(separatedBy:"\n")
        var emptyLines = 0
        for x in numLines {
            if x == ""{
                emptyLines=emptyLines+1
            }
        }
        return (numLines.count-emptyLines)
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}
